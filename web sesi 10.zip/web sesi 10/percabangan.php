<?php
$nilai =80;
if ($nilai >80) {
    echo "Anda Lulus dengan Grade A";
}else if ($nilai >75){
    echo "Anda Tidak Lulus dengan Grade B";
}
?>